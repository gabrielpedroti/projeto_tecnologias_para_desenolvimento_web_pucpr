export default function Home() {
  return <h2 style={{textAlign:'center'}}>Home</h2>;
}
