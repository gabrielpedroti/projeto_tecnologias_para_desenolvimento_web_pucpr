import { useState } from "react";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { auth, db } from "../firebase";
import { useNavigate } from "react-router-dom";

export default function Cadastro(){
  const [form, setForm] = useState({
    email: "",
    senha: "",
    nome: "",
    sobrenome: "",
    dataNascimento: "",
  });
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();

  function onChange(e){
    const { name, value } = e.target;
    setForm(prev => ({...prev, [name]: value}));
  }

  async function onSubmit(e){
    e.preventDefault();
    setMsg("");
    try{
      // 1) Cria usuário no Auth
      const cred = await createUserWithEmailAndPassword(auth, form.email, form.senha);
      const uid = cred.user.uid;

      // 2) Persiste dados no Firestore (doc = UID)
      await setDoc(doc(db, "usuarios", uid), {
        uid,
        email: form.email,
        nome: form.nome,
        sobrenome: form.sobrenome,
        // salva data como string ISO para evitar problemas de timezone
        dataNascimento: form.dataNascimento, 
        criadoEm: new Date().toISOString(),
      });

      setMsg("Cadastro realizado com sucesso! Você já pode acessar a página principal.");
      // opcional: redireciona direto para principal
      setTimeout(()=> navigate("/principal"), 800);
    }catch(err){
      setMsg("Erro ao cadastrar: " + (err?.code || "verifique os dados"));
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h1>Cadastro</h1>
        <form onSubmit={onSubmit}>
          <div className="field">
            <label>E-mail</label>
            <input type="email" name="email" value={form.email} onChange={onChange} required />
          </div>
          <div className="field">
            <label>Senha</label>
            <input type="password" name="senha" value={form.senha} onChange={onChange} required />
          </div>
          <div className="field">
            <label>Nome</label>
            <input name="nome" value={form.nome} onChange={onChange} required />
          </div>
          <div className="field">
            <label>Sobrenome</label>
            <input name="sobrenome" value={form.sobrenome} onChange={onChange} required />
          </div>
          <div className="field">
            <label>Data de nascimento</label>
            <input type="date" name="dataNascimento" value={form.dataNascimento} onChange={onChange} required />
          </div>
          <button className="btn" type="submit">Cadastrar</button>
        </form>
        <p className="mensagem">{msg}</p>
      </div>
    </div>
  );
}
